/* =========================================================================
   LuckyDraw — visual tools (coin / number / pick / wheel / teams)
   Each tool exposes:  init(stage) · render(state) · play(event, {skipMs}) → Promise<summary> · reset()
   `play()` animates a *server-produced* event so that host and viewers see the
   exact same outcome; `skipMs` lets late viewers fast-forward into the animation.
   ========================================================================= */
(function () {
  'use strict';
  const U = window.LDU;
  const { $, $$, fmt, fmtNum, sound } = U; const tr = U.T; const SEP = U.SEP;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  /** sound/confetti wrappers that respect opts.quiet (stale events on late-joining viewers) */
  let quiet = false;
  const fx = {
    sound: new Proxy({}, { get: (_, k) => (...a) => { if (!quiet && typeof sound[k] === 'function') return sound[k](...a); } }),
    burst: (s) => { if (!quiet) U.confettiBurst(s); },
    sides: (ms) => { if (!quiet) U.confettiSides(ms); },
  };
  const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);
  const easeOutQuint = (t) => 1 - Math.pow(1 - t, 5);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ------------------------------------------------------------------ */
  /* result banner                                                       */
  /* ------------------------------------------------------------------ */
  function banner(summary) {
    const el = $('#resultBanner'); if (!el) return;
    if (!summary) { el.hidden = true; return; }
    $('#resultKicker').textContent = summary.kicker || '';
    $('#resultMain').textContent = summary.main || '';
    $('#resultSub').textContent = summary.sub || '';
    el.hidden = false;
    el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
  }

  /* ================================================================== */
  /* COIN                                                                */
  /* ================================================================== */
  const coin = {
    arena: null, state: null, coins: [],
    init(stage) { this.arena = $('#coinArena', stage); this.stats = $('#coinStats', stage); },
    sizeClass(n) { return n <= 2 ? '' : n <= 5 ? 'small' : 'tiny'; },
    render(state) {
      this.state = state;
      const n = clamp(state.count || 1, 1, 10);
      this.arena.innerHTML = '';
      this.coins = [];
      for (let i = 0; i < n; i++) {
        const c = document.createElement('div');
        c.className = 'coin3d ' + this.sizeClass(n);
        c.innerHTML = `<div class="coin-edge"></div><div class="coin-face heads"><span><i class="fa-solid fa-crown"></i><span class="lbl"></span></span></div><div class="coin-face tails"><span><i class="fa-solid fa-star"></i><span class="lbl"></span></span></div>`;
        c.querySelector('.heads .lbl').textContent = state.heads;
        c.querySelector('.tails .lbl').textContent = state.tails;
        this.arena.appendChild(c);
        this.coins.push(c);
      }
      if (this.stats) {
        $('#statHeads').textContent = state.heads; $('#statTails').textContent = state.tails;
        this.stats.hidden = n < 2;
        $$('b', this.stats).forEach((b) => (b.textContent = fmt(0)));
      }
      banner(null);
    },
    async play(event, opts) {
      const skip = (opts && opts.skipMs) || 0; quiet = !!(opts && opts.quiet);
      const st = event.state; const res = event.result;
      this.render(st);
      const dur = res.duration || 2600;
      if (skip < dur) fx.sound.coin();
      this.coins.forEach((c, i) => {
        const side = res.sides[i] || 0;
        const turns = (res.flips + i) * 360 + side * 180;
        c.style.setProperty('--turns', turns + 'deg');
        c.style.setProperty('--dur', dur + 'ms');
        c.style.animationDelay = (-skip - i * 60) + 'ms';
        c.classList.add('flipping');
      });
      await sleep(Math.max(0, dur - skip + 80));
      this.coins.forEach((c, i) => {
        const side = res.sides[i] || 0;
        c.classList.remove('flipping');
        c.style.animationDelay = '';
        c.style.transform = `rotateY(${(res.flips + i) * 360 + side * 180}deg)`;
        c.classList.add('landed');
      });
      fx.sound.land();
      const heads = res.sides.filter((s) => s === 0).length;
      const tails = res.sides.length - heads;
      if (this.stats && res.sides.length > 1) {
        $('b[data-side="0"]', this.stats).textContent = fmt(heads);
        $('b[data-side="1"]', this.stats).textContent = fmt(tails);
      }
      const labels = res.sides.map((s) => (s === 0 ? st.heads : st.tails));
      const summary = {
        kicker: tr('flip_result'),
        main: res.sides.length === 1 ? labels[0] : labels.join(SEP),
        sub: res.sides.length > 1 ? `${st.heads}: ${fmt(heads)} — ${st.tails}: ${fmt(tails)}` : '',
        history: { at: event.at, items: res.sides, labels: [st.heads, st.tails] },
      };
      banner(summary);
      if (res.sides.length === 1) fx.burst(0.5); else fx.burst(0.7);
      return summary;
    },
    reset() { if (this.state) this.render(this.state); },
  };

  /* ================================================================== */
  /* NUMBER                                                              */
  /* ================================================================== */
  const number = {
    init(stage) { this.slots = $('#numberSlots', stage); this.range = $('#numberRange', stage); },
    render(state) {
      this.state = state;
      this.range.textContent = tr('range_label', fmtNum(state.min), fmtNum(state.max)) + (state.count > 1 ? tr('range_count', fmt(state.count)) + (state.unique ? tr('range_unique') : '') : '');
      this.slots.innerHTML = '';
      const n = clamp(state.count || 1, 1, 100);
      for (let i = 0; i < n; i++) {
        const s = document.createElement('div');
        s.className = 'slot num placeholder' + (n > 8 ? ' many' : '');
        s.textContent = '?';
        this.slots.appendChild(s);
      }
      banner(null);
    },
    async play(event, opts) {
      const skip = (opts && opts.skipMs) || 0; quiet = !!(opts && opts.quiet);
      const st = event.state; const res = event.result;
      this.render(st);
      const slots = $$('.slot', this.slots);
      const nums = res.numbers;
      const n = nums.length;
      const total = res.duration || 2600;
      const base = Math.max(900, total - Math.min(n, 12) * 260);
      const stagger = n > 1 ? (total - base) / Math.max(1, Math.min(n, 12) - 1) : 0;
      const stopAt = nums.map((_, i) => base + Math.min(i, 11) * stagger + (i > 11 ? (i - 11) * 40 : 0));
      const span = st.max - st.min;
      const t0 = performance.now() - skip;
      const done = new Array(n).fill(false);
      slots.forEach((s) => { s.classList.remove('placeholder'); s.classList.add('rolling'); });
      await new Promise((resolve) => {
        let lastTick = 0;
        const frame = (now) => {
          const el = now - t0;
          let allDone = true;
          for (let i = 0; i < n; i++) {
            if (done[i]) continue;
            if (el >= stopAt[i]) {
              done[i] = true;
              slots[i].classList.remove('rolling'); slots[i].classList.add('done');
              slots[i].textContent = fmtNum(nums[i]);
              slots[i].setAttribute('data-raw', String(nums[i]));
              fx.sound.blip(i);
            } else {
              allDone = false;
              if (now - lastTick > 45) slots[i].textContent = fmtNum(st.min + Math.floor(Math.random() * (span + 1)));
            }
          }
          if (now - lastTick > 45) lastTick = now;
          if (allDone) resolve(); else requestAnimationFrame(frame);
        };
        requestAnimationFrame(frame);
      });
      const summary = {
        kicker: n === 1 ? tr('random_number') : tr('random_numbers'),
        main: nums.map((x) => fmtNum(x)).join(SEP),
        sub: tr('range_sub', fmtNum(st.min), fmtNum(st.max)),
        history: { at: event.at, items: nums },
      };
      banner(summary);
      fx.sound.win();
      fx.burst(0.6);
      return summary;
    },
    reset() { if (this.state) this.render(this.state); },
  };

  /* ================================================================== */
  /* PICK                                                                */
  /* ================================================================== */
  const pick = {
    MAX_CLOUD: 160,
    init(stage) { this.cloud = $('#pickCloud', stage); this.winners = $('#pickWinners', stage); },
    render(state, keepWinners) {
      this.state = state;
      const items = state.items || [];
      this.cloud.innerHTML = '';
      this.tags = [];
      const shown = items.slice(0, this.MAX_CLOUD);
      shown.forEach((it, i) => {
        const t = document.createElement('span');
        t.className = 'name'; t.textContent = it.n + (U.fmtWeight(it.w) ? ' ' + U.fmtWeight(it.w) : '');
        t.dataset.i = i;
        this.cloud.appendChild(t); this.tags.push(t);
      });
      if (items.length > shown.length) {
        const m = document.createElement('span'); m.className = 'more'; m.textContent = tr('and_more', fmt(items.length - shown.length)); this.cloud.appendChild(m);
      }
      if (!items.length) { const m = document.createElement('div'); m.className = 'wheel-empty'; m.innerHTML = '<i class="fa-solid fa-user-plus"></i> '; m.appendChild(document.createTextNode(tr('enter_list'))); this.cloud.appendChild(m); }
      if (!keepWinners) { this.winners.innerHTML = ''; this.winners.hidden = true; banner(null); }
    },
    async play(event, opts) {
      const skip = (opts && opts.skipMs) || 0; quiet = !!(opts && opts.quiet);
      const st = event.state; const res = event.result;
      this.render(st);
      const items = st.items;
      const total = res.duration || 3000;
      const count = res.indexes.length;
      const per = total / count;
      const start = performance.now() - skip;
      const wonSet = new Set();
      let lit = null;
      const light = (idx) => {
        if (lit) lit.classList.remove('lit');
        lit = this.tags[idx] || null;
        if (lit) lit.classList.add('lit');
      };
      for (let k = 0; k < count; k++) {
        const target = res.indexes[k];
        const endAt = start + per * (k + 1);
        // roulette sweep: quick random highlights slowing down toward the end
        await new Promise((resolve) => {
          let nextAt = 0;
          const frame = (now) => {
            if (now >= endAt - 60) { resolve(); return; }
            if (now >= nextAt) {
              const progress = clamp((now - (start + per * k)) / per, 0, 1);
              const interval = 40 + easeOutQuart(progress) * 260;
              nextAt = now + interval;
              // prefer a tag that is neither already won nor currently lit; give up
              // after a few tries so the loop can never hang when few candidates remain
              const n = Math.min(items.length, this.tags.length);
              let idx = Math.floor(Math.random() * n);
              for (let tries = 0; tries < 12 && n > 2 && (wonSet.has(idx) || (lit && lit.dataset.i == idx)); tries++) idx = Math.floor(Math.random() * n);
              light(idx);
              if (progress > 0.35) fx.sound.tick();
            }
            requestAnimationFrame(frame);
          };
          requestAnimationFrame(frame);
        });
        if (lit) lit.classList.remove('lit');
        wonSet.add(target);
        // the final pick lands in blue first ("lit"), holds a beat, then turns gold ("won")
        const tag = this.tags[target] || null;
        if (tag) { tag.classList.add('landed'); fx.sound.tick(); }
        await sleep(quiet ? 0 : (count > 3 ? 380 : 700));
        if (tag) { tag.classList.remove('landed'); tag.classList.add('won'); }
        const w = document.createElement('div');
        w.className = 'pick-winner';
        w.innerHTML = `<span class="n num">${fmt(k + 1)}</span><i class="fa-solid fa-star"></i><span></span>`;
        w.querySelector('span:last-child').textContent = items[target].n;
        this.winners.appendChild(w); this.winners.hidden = false;
        fx.sound.win();
        fx.burst(count > 3 ? 0.35 : 0.8);
        if (k < count - 1) await sleep(Math.max(0, Math.min(500, endAt - performance.now() + 500)));
      }
      const names = res.picked.map((it) => it.n);
      const summary = {
        kicker: count === 1 ? tr('picked_one') : tr('picked_n', fmt(count)),
        main: names.join(SEP),
        sub: tr('out_of_people', fmt(items.length)),
        history: { at: event.at, items: names },
      };
      banner(summary);
      if (st.remove) {
        // fade out removed names
        res.indexes.forEach((i) => { if (this.tags[i]) this.tags[i].classList.add('gone'); });
      }
      return summary;
    },
    reset() { if (this.state) this.render(this.state); },
  };

  /* ================================================================== */
  /* WHEEL                                                               */
  /* ================================================================== */
  const PALETTE = ['#7c5cff', '#ff5c8a', '#ffb02e', '#27d17f', '#4f9dff', '#ff7a45', '#a855f7', '#22d3ee', '#f43f5e', '#84cc16', '#eab308', '#0ea5e9'];
  const wheel = {
    rotation: 0, // degrees, cumulative
    spinning: false,
    init(stage) {
      this.wrap = $('#wheelWrap', stage); this.canvas = $('#wheelCanvas', stage); this.hub = $('#wheelHub', stage);
      this.pointer = $('#wheelPointer', stage); this.current = $('#wheelCurrent', stage); this.lights = $('.wheel-lights', stage);
      this.ctx = this.canvas.getContext('2d');
      // lights ring
      for (let i = 0; i < 24; i++) {
        const b = document.createElement('b');
        const a = (i / 24) * Math.PI * 2;
        b.style.left = (50 + 47.5 * Math.cos(a)) + '%'; b.style.top = (50 + 47.5 * Math.sin(a)) + '%';
        this.lights.appendChild(b);
      }
      window.addEventListener('resize', () => this.draw());
      document.addEventListener('ld:digits', () => this.draw());
    },
    computeSlices(items) {
      const wt = (it) => U.parseWeight(it.w == null ? 1 : it.w);
      const total = items.reduce((s, it) => s + wt(it), 0) || 1;
      let a = 0; const out = [];
      items.forEach((it, i) => {
        const span = (wt(it) / total) * Math.PI * 2;
        out.push({ i, start: a, end: a + span, mid: a + span / 2, name: it.n, w: wt(it) });
        a += span;
      });
      return out;
    },
    colorFor(i, n) {
      const p = PALETTE.length;
      let c = PALETTE[i % p];
      if (i === n - 1 && n > 1 && i % p === 0) c = PALETTE[Math.floor(p / 2)]; // avoid first/last same colour
      return c;
    },
    render(state) {
      this.state = state;
      this.items = (state.items || []).slice();
      this.slices = this.computeSlices(this.items);
      this.draw();
      this.wrap.classList.remove('celebrate');
      this.current.classList.remove('win');
      this.current.textContent = '';
      if (this.items.length < 2) {
        this.current.innerHTML = '<span class="wheel-empty"><i class="fa-solid fa-user-plus"></i> </span>'; this.current.firstChild.appendChild(document.createTextNode(tr('enter_two')));
      }
      banner(null);
    },
    draw() {
      const canvas = this.canvas; const ctx = this.ctx;
      const cssSize = canvas.clientWidth || 520;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const size = Math.round(cssSize * dpr);
      if (canvas.width !== size) { canvas.width = size; canvas.height = size; }
      const R = size / 2; const cx = R; const cy = R;
      ctx.clearRect(0, 0, size, size);
      const items = this.items || []; const n = items.length; const slices = this.slices || [];
      // base disc
      ctx.save();
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fillStyle = '#1b2240'; ctx.fill();
      if (n === 0) {
        ctx.restore();
        this.drawRim(ctx, cx, cy, R);
        return;
      }
      const labelPx = n <= 6 ? R * 0.085 : n <= 10 ? R * 0.07 : n <= 16 ? R * 0.058 : n <= 24 ? R * 0.046 : n <= 36 ? R * 0.036 : n <= 60 ? R * 0.026 : 0;
      const dark = document.documentElement.getAttribute('data-theme') !== 'light';
      slices.forEach((s) => {
        ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, R * 0.965, s.start, s.end); ctx.closePath();
        const col = this.colorFor(s.i, n);
        const g = ctx.createRadialGradient(cx, cy, R * 0.2, cx, cy, R);
        g.addColorStop(0, shade(col, 18)); g.addColorStop(1, shade(col, -12));
        ctx.fillStyle = g; ctx.fill();
        if (n <= 120) { ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = Math.max(1, R * 0.004); ctx.stroke(); }
      });
      // labels
      if (labelPx > 0) {
        ctx.font = `700 ${labelPx}px Vazirmatn, sans-serif`;
        ctx.textBaseline = 'middle';
        ctx.direction = document.documentElement.dir === 'ltr' ? 'ltr' : 'rtl'; // bidi base for mixed labels
        ctx.textAlign = 'right';
        const outer = R * 0.9; const inner = R * 0.25;
        slices.forEach((s) => {
          const text = fitText(ctx, s.name + (U.fmtWeight(s.w) ? ' ' + U.fmtWeight(s.w) : ''), outer - inner);
          ctx.save(); ctx.translate(cx, cy); ctx.rotate(s.mid);
          // keep labels upright on the left half of the wheel
          const a = ((s.mid % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
          if (a > Math.PI / 2 && a < Math.PI * 1.5) { ctx.rotate(Math.PI); ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillText(text, -outer + 1.5, 1.5); ctx.fillStyle = '#fff'; ctx.fillText(text, -outer, 0); ctx.textAlign = 'right'; }
          else { ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillText(text, outer + 1.5, 1.5); ctx.fillStyle = '#fff'; ctx.fillText(text, outer, 0); }
          ctx.restore();
        });
      }
      ctx.restore();
      this.drawRim(ctx, cx, cy, R, dark);
    },
    drawRim(ctx, cx, cy, R) {
      ctx.save();
      ctx.beginPath(); ctx.arc(cx, cy, R * 0.98, 0, Math.PI * 2);
      ctx.lineWidth = R * 0.04; const g = ctx.createLinearGradient(0, 0, R * 2, R * 2);
      g.addColorStop(0, '#fff2b3'); g.addColorStop(0.5, '#d19a00'); g.addColorStop(1, '#fff2b3');
      ctx.strokeStyle = g; ctx.stroke();
      ctx.beginPath(); ctx.arc(cx, cy, R * 0.955, 0, Math.PI * 2); ctx.lineWidth = R * 0.008; ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.stroke();
      ctx.restore();
    },
    /** local angle (radians) currently under the pointer (world angle 0 = right) */
    sliceAt(rotationDeg) {
      const rot = ((rotationDeg % 360) + 360) % 360;
      const local = ((360 - rot) % 360) * Math.PI / 180;
      const slices = this.slices || [];
      for (const s of slices) if (local >= s.start && local < s.end) return s;
      return slices[slices.length - 1] || null;
    },
    setRotation(deg) { this.rotation = deg; this.canvas.style.transform = `rotate(${deg}deg)`; },
    async play(event, opts) {
      const skip = (opts && opts.skipMs) || 0; quiet = !!(opts && opts.quiet);
      const st = event.state; const res = event.result;
      this.render(st);
      const slices = this.slices;
      const target = slices[res.index];
      if (!target) throw new Error('bad index');
      const thetaP = target.start + (res.offset || 0.5) * (target.end - target.start);
      const targetMod = ((Math.PI * 2 - thetaP) % (Math.PI * 2)) * 180 / Math.PI; // degrees
      const from = ((this.rotation % 360) + 360) % 360;
      const delta = ((targetMod - from) % 360 + 360) % 360;
      const total = (res.turns || 6) * 360 + delta;
      const dur = res.duration || 7000;
      this.spinning = true;
      this.wrap.classList.add('spinning');
      this.current.classList.remove('win');
      if (this.hub) this.hub.disabled = true;
      const t0 = performance.now() - skip;
      let lastSlice = null;
      await new Promise((resolve) => {
        const frame = (now) => {
          const t = clamp((now - t0) / dur, 0, 1);
          const rot = from + total * easeOutQuint(t);
          this.setRotation(rot);
          const s = this.sliceAt(rot);
          if (s && s !== lastSlice) {
            lastSlice = s;
            this.current.textContent = s.name;
            fx.sound.tick();
            this.pointer.classList.remove('tick'); void this.pointer.offsetWidth; this.pointer.classList.add('tick');
          }
          if (t < 1) requestAnimationFrame(frame); else resolve();
        };
        requestAnimationFrame(frame);
      });
      this.setRotation(from + total);
      this.spinning = false;
      this.wrap.classList.remove('spinning');
      this.wrap.classList.add('celebrate');
      this.current.textContent = res.winner.n;
      this.current.classList.add('win');
      fx.sound.win();
      fx.burst(1);
      fx.sides(2200);
      const summary = {
        kicker: tr('winner'),
        main: res.winner.n,
        sub: tr('out_of_options', fmt(st.items.length)) + (st.remove ? tr('removed_from_list') : ''),
        history: { at: event.at, items: [res.winner.n] },
      };
      banner(summary);
      return summary;
    },
    reset() { if (this.state) this.render(this.state); },
  };


  /* ================================================================== */
  /* TEAMS                                                               */
  /* ================================================================== */
  const TEAM_COLORS = ['#7c5cff', '#ff5c8a', '#27d17f', '#ffb02e', '#4f9dff', '#ff7a45', '#a855f7', '#22d3ee', '#f43f5e', '#84cc16', '#eab308', '#0ea5e9'];
  const TEAM_ICONS = ['fa-star', 'fa-bolt', 'fa-fire', 'fa-leaf', 'fa-gem', 'fa-crown', 'fa-heart', 'fa-sun', 'fa-moon', 'fa-rocket', 'fa-shield-halved', 'fa-feather'];
  const teams = {
    init(stage) { this.pool = $('#teamsPool', stage); this.grid = $('#teamsGrid', stage); },
    groupCount(state, members) {
      let n = state.n || 2;
      if (state.by === 'size') n = Math.ceil(members / Math.max(1, n));
      return Math.max(1, Math.min(n, Math.max(1, members)));
    },
    groupName(state, i) { const nm = (state.names || [])[i]; return nm && nm.trim() ? nm : tr('group_n', fmt(i + 1)); },
    render(state, keep) {
      this.state = state;
      const items = state.items || [];
      this.pool.innerHTML = ''; this.grid.innerHTML = '';
      this.grid.classList.remove('ready');
      if (!items.length) { this.pool.innerHTML = '<div class="wheel-empty"><i class="fa-solid fa-user-plus"></i> </div>'; this.pool.firstChild.appendChild(document.createTextNode(tr('enter_people'))); banner(null); return; }
      const n = this.groupCount(state, items.length);
      // idle preview: empty group cards + a pool of chips
      this.chips = items.slice(0, 200).map((it) => { const c = document.createElement('span'); c.className = 'chip-name'; c.textContent = it.n; this.pool.appendChild(c); return c; });
      if (items.length > 200) { const m = document.createElement('span'); m.className = 'more'; m.textContent = `+${fmt(items.length - 200)}`; this.pool.appendChild(m); }
      this.cards = [];
      for (let g = 0; g < n; g++) this.cards.push(this.card(g, this.groupName(state, g), n));
      this.grid.dataset.n = n;
      this.grid.style.setProperty('--cols', n <= 2 ? n : n <= 4 ? 2 : n <= 9 ? 3 : 4);
      if (!keep) banner(null);
    },
    card(g, name, n) {
      const el = document.createElement('div');
      el.className = 'team-card';
      el.style.setProperty('--c', TEAM_COLORS[g % TEAM_COLORS.length]);
      el.innerHTML = `<div class="team-head"><i class="fa-solid ${TEAM_ICONS[g % TEAM_ICONS.length]}"></i><span class="team-name"></span><b class="team-count num">${fmt(0)}</b></div><div class="team-members"></div>`;
      el.querySelector('.team-name').textContent = name;
      this.grid.appendChild(el);
      return el;
    },
    async play(event, opts) {
      const skip = (opts && opts.skipMs) || 0; quiet = !!(opts && opts.quiet);
      const st = event.state; const res = event.result;
      this.render(st, true);
      const items = st.items; const groups = res.groups; const n = groups.length;
      // deal order: round-robin, same as the server produced it
      const order = [];
      const maxLen = Math.max(...groups.map((g) => g.length));
      for (let r = 0; r < maxLen; r++) for (let g = 0; g < n; g++) if (groups[g][r] !== undefined) order.push({ g, i: groups[g][r] });
      const total = res.duration || 3000;
      const per = total / Math.max(1, order.length);
      const t0 = performance.now() - skip;
      let k = 0;
      await new Promise((resolve) => {
        const frame = (now) => {
          const should = Math.min(order.length, Math.floor((now - t0) / per) + 1);
          while (k < should) { this.deal(order[k], items); k++; }
          if (k >= order.length) resolve(); else requestAnimationFrame(frame);
        };
        requestAnimationFrame(frame);
      });
      this.grid.classList.add('ready');
      this.cards.forEach((c, g) => { c.classList.add('done'); c.style.animationDelay = (g * 60) + 'ms'; });
      fx.sound.win();
      fx.burst(0.8);
      const lines = groups.map((g, gi) => `${this.groupName(st, gi)}: ${g.map((i) => items[i].n).join(SEP)}`);
      const summary = {
        kicker: tr('people_in_groups', fmt(items.length), fmt(n)),
        main: groups.map((g, gi) => `${this.groupName(st, gi)} (${fmt(g.length)})`).join(' • '),
        sub: '',
        history: { at: event.at, items: lines },
      };
      banner(summary);
      return summary;
    },
    deal(o, items) {
      const card = this.cards[o.g]; if (!card) return;
      const chip = this.chips[o.i];
      const m = document.createElement('span'); m.className = 'member'; m.textContent = items[o.i].n;
      card.querySelector('.team-members').appendChild(m);
      const cnt = card.querySelector('.team-count'); cnt.textContent = fmt(card.querySelectorAll('.member').length);
      card.classList.remove('pulse'); void card.offsetWidth; card.classList.add('pulse');
      if (chip) { chip.classList.add('dealt'); chip.style.setProperty('--c', TEAM_COLORS[o.g % TEAM_COLORS.length]); }
      fx.sound.blip(o.g);
    },
    reset() { if (this.state) this.render(this.state); },
  };

  /* ---------------- helpers ---------------- */
  function shade(hex, pct) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const f = (c) => clamp(Math.round(c + (pct > 0 ? (255 - c) * pct / 100 : c * pct / 100)), 0, 255);
    return `rgb(${f(r)},${f(g)},${f(b)})`;
  }
  function fitText(ctx, text, maxW) {
    if (ctx.measureText(text).width <= maxW) return text;
    let t = text;
    while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
    return t + '…';
  }

  window.LDTools = { coin, number, pick, wheel, teams, banner, sleep };
})();
